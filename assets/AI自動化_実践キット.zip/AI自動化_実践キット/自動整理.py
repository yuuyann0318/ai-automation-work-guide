#!/usr/bin/env python3
"""確認済みの商品資料を、根拠付きの固定列へ整理するローカル処理。"""

from __future__ import annotations

import argparse
import csv
import hashlib
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


PRODUCT_FILE = "01-products.csv"
FACT_FILE = "02-facts.md"
PRODUCT_COLUMNS = ("商品ID", "商品名")
FACT_COLUMNS = ("商品ID", "確認済み内容", "未確認項目")
DELIVERY_COLUMNS = ("商品ID", "商品名", "確認済み内容", "確認事項", "根拠")
CHECK_COLUMNS = ("商品ID", "商品名", "確認事項", "理由", "根拠")


class ValidationError(Exception):
    pass


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require_plain_file(path: Path) -> None:
    if not path.exists():
        raise ValidationError(f"必要な入力ファイルがありません: {path.name}")
    if path.is_symlink() or not path.is_file():
        raise ValidationError(f"通常ファイルではありません: {path.name}")


def require_columns(actual: Sequence[str], required: Sequence[str], filename: str) -> None:
    missing = [name for name in required if name not in actual]
    if missing:
        raise ValidationError(f"{filename} に必要な列がありません: {'、'.join(missing)}")


def read_products(path: Path) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValidationError(f"{path.name} の見出し行がありません")
        fieldnames = [name.strip() for name in reader.fieldnames]
        require_columns(fieldnames, PRODUCT_COLUMNS, path.name)
        rows: List[Dict[str, str]] = []
        seen = set()
        for line_number, raw in enumerate(reader, start=2):
            product_id = (raw.get("商品ID") or "").strip()
            product_name = (raw.get("商品名") or "").strip()
            if not product_id:
                raise ValidationError(f"{path.name} {line_number}行目の商品IDが空欄です")
            if product_id in seen:
                raise ValidationError(f"{path.name} の商品IDが重複しています: {product_id}")
            seen.add(product_id)
            rows.append({"商品ID": product_id, "商品名": product_name})
    if not rows:
        raise ValidationError(f"{path.name} に商品がありません")
    return rows


def markdown_cells(line: str) -> List[str]:
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def is_separator_row(cells: Sequence[str]) -> bool:
    return bool(cells) and all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells)


def read_facts(path: Path) -> Dict[str, Dict[str, str]]:
    table_lines = [line for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip().startswith("|")]
    if not table_lines:
        raise ValidationError(f"{path.name} にMarkdown表がありません")
    header = markdown_cells(table_lines[0])
    require_columns(header, FACT_COLUMNS, path.name)
    facts: Dict[str, Dict[str, str]] = {}
    for table_index, line in enumerate(table_lines[1:], start=2):
        cells = markdown_cells(line)
        if is_separator_row(cells):
            continue
        if len(cells) != len(header):
            raise ValidationError(f"{path.name} の表{table_index}行目は列数が合いません")
        row = dict(zip(header, cells))
        product_id = row["商品ID"].strip()
        if not product_id:
            raise ValidationError(f"{path.name} の表{table_index}行目の商品IDが空欄です")
        if product_id in facts:
            raise ValidationError(f"{path.name} の商品IDが重複しています: {product_id}")
        facts[product_id] = {
            "確認済み内容": row["確認済み内容"].strip(),
            "未確認項目": row["未確認項目"].strip(),
        }
    return facts


def split_check_items(text: str) -> List[str]:
    if not text.strip():
        return []
    return [item.strip() for item in re.split(r"[・／、;；\n]+", text) if item.strip()]


def build_outputs(
    products: Sequence[Dict[str, str]], facts: Dict[str, Dict[str, str]]
) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
    product_ids = {row["商品ID"] for row in products}
    orphan_ids = sorted(set(facts) - product_ids)
    if orphan_ids:
        raise ValidationError(f"{FACT_FILE} に商品一覧にないIDがあります: {'、'.join(orphan_ids)}")

    delivery_rows: List[Dict[str, str]] = []
    check_rows: List[Dict[str, str]] = []
    for product in products:
        product_id = product["商品ID"]
        product_name = product["商品名"]
        source = facts.get(product_id)
        confirmed = source["確認済み内容"] if source else ""
        root = f"{PRODUCT_FILE}:商品ID={product_id}"
        if source:
            root += f"／{FACT_FILE}:商品ID={product_id}"

        checks: List[Tuple[str, str]] = []
        if not product_name:
            checks.append(("商品名が空欄です", "商品一覧の空欄"))
        if source is None:
            checks.append(("事実資料が見つかりません", "商品IDに対応する事実資料がありません"))
        else:
            if not confirmed:
                checks.append(("確認済み内容が空欄です", "事実資料の空欄"))
            for item in split_check_items(source["未確認項目"]):
                checks.append((item, "元資料で未確認"))

        confirmation_text = "／".join(item for item, _ in checks)
        delivery_rows.append(
            {
                "商品ID": product_id,
                "商品名": product_name,
                "確認済み内容": confirmed,
                "確認事項": confirmation_text,
                "根拠": root,
            }
        )
        for item, reason in checks:
            check_rows.append(
                {
                    "商品ID": product_id,
                    "商品名": product_name,
                    "確認事項": item,
                    "理由": reason,
                    "根拠": root,
                }
            )
    return delivery_rows, check_rows


def new_run_directory(output_root: Path) -> Path:
    output_root.mkdir(parents=True, exist_ok=True)
    base_name = datetime.now().strftime("run-%Y%m%d-%H%M%S-%f")
    candidate = output_root / base_name
    suffix = 2
    while candidate.exists():
        candidate = output_root / f"{base_name}-{suffix:02d}"
        suffix += 1
    candidate.mkdir()
    return candidate


def write_csv(path: Path, columns: Sequence[str], rows: Iterable[Dict[str, str]]) -> None:
    def safe_cell(value: str) -> str:
        text = str(value)
        if text.lstrip().startswith(("=", "+", "-", "@")):
            return "'" + text
        return text

    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(columns), extrasaction="ignore")
        writer.writeheader()
        writer.writerows({key: safe_cell(value) for key, value in row.items()} for row in rows)


def write_summary(
    path: Path,
    delivery_rows: Sequence[Dict[str, str]],
    check_rows: Sequence[Dict[str, str]],
    input_hashes: Dict[str, str],
) -> None:
    confirmed_count = sum(bool(row["確認済み内容"]) for row in delivery_rows)
    lines = [
        "# 実行結果",
        "",
        f"- 商品数: {len(delivery_rows)}件",
        f"- 確認済み内容がある商品: {confirmed_count}件",
        f"- 確認事項: {len(check_rows)}件",
        "- 追加依存: なし（Python 3の標準機能だけを使用）",
        "- 外部送信: なし",
        "",
        "## 自動で行ったこと",
        "",
        "商品IDで2つの資料を結び、確認済み内容を固定5列へそろえました。空欄と未確認項目は確認リストへ分けました。文章や事実は追加していません。",
        "",
        "## 人が確認すること",
        "",
        "提出前に元資料と全行を照合し、確認事項を依頼主へ確認してください。契約、納品、顧客への送信は人が判断します。",
        "",
        "## 入力ファイルのSHA-256",
        "",
    ]
    lines.extend(f"- `{name}`: `{digest}`" for name, digest in input_hashes.items())
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(input_dir: Path, output_root: Path) -> Path:
    input_dir = input_dir.expanduser().resolve()
    output_root = output_root.expanduser().resolve()
    if output_root == input_dir or input_dir in output_root.parents:
        raise ValidationError("出力先は入力フォルダの外に指定してください")
    product_path = input_dir / PRODUCT_FILE
    fact_path = input_dir / FACT_FILE
    require_plain_file(product_path)
    require_plain_file(fact_path)
    input_hashes = {path.name: file_sha256(path) for path in (product_path, fact_path)}

    products = read_products(product_path)
    facts = read_facts(fact_path)
    delivery_rows, check_rows = build_outputs(products, facts)

    run_dir = new_run_directory(output_root)
    write_csv(run_dir / "提出用_商品一覧.csv", DELIVERY_COLUMNS, delivery_rows)
    write_csv(run_dir / "確認リスト.csv", CHECK_COLUMNS, check_rows)
    write_summary(run_dir / "実行結果.md", delivery_rows, check_rows, input_hashes)

    after_hashes = {path.name: file_sha256(path) for path in (product_path, fact_path)}
    if after_hashes != input_hashes:
        raise RuntimeError("処理中に入力ファイルが変わりました。出力を提出せず、入力を確認してください")
    return run_dir


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="確認済みの商品資料を、根拠付きの固定列へ整理します。")
    parser.add_argument("--input-dir", type=Path, default=script_dir / "入力例")
    parser.add_argument("--output-root", type=Path, default=script_dir / "outputs")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])
    try:
        run_dir = run(args.input_dir, args.output_root)
    except (ValidationError, OSError, UnicodeError, csv.Error) as error:
        print(f"入力エラー: {error}", file=sys.stderr)
        return 2
    except RuntimeError as error:
        print(f"実行エラー: {error}", file=sys.stderr)
        return 3
    print(f"完了: {run_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
